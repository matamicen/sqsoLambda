var fs = require('fs');
var mysql = require('mysql');
// var async = require('async');
var AWS = require('aws-sdk');
AWS.config.region = 'us-east-1';
var lambda = new AWS.Lambda();

exports.handler = (event, context, callback) => {


    context.callbackWaitsForEmptyEventLoop = false;

    var Sub;
    var Name;
    var post;
var qso;
    var media;
    var json;
    
    var idqra_owner;
 var idmedia;
 

    var response = {
        "message": "",
        "error": ""
    };

    // var count;
    if (process.env.TEST) {
        var test = {  
          "idmedia": 1892,
          "qso":  1307
        };
 
    }
    else {
        qso = event.body.qso
        idmedia = event.body.idmedia;
    }

    if (process.env.TEST){
        Sub = "7bec5f23-6661-4ba2-baae-d1d4f0440038";
    }else if (event.context.sub){
        Sub = event.context.sub;
    }
    console.log("sub =", Sub);


    //***********************************************************
    var conn = mysql.createConnection({
        host      :  'sqso.clqrfqgg8s70.us-east-1.rds.amazonaws.com' ,  // give your RDS endpoint  here
        user      :  'sqso' ,  // Enter your  MySQL username
        password  :  'parquepatricios' ,  // Enter your  MySQL password
        database  :  'sqso'    // Enter your  MySQL database name.
    });

    // GET QRA ID of OWNER
    console.log("select QRA to get ID of Owner");
    console.log(qso);
    conn.query ( "SELECT qras.idqras, qras.qra from qras inner join qsos on qras.idqras = qsos.idqra_owner where qsos.idqsos =? and qras.idcognito=?", [qso , Sub],   function(error,info) {
        if (error) {
            console.log("Error when select QRA to get ID of Owner");
            console.log(error);
            conn.destroy();
            response.error = 400;
            response.message = "Error: select QRA to get ID of Owner";
            // return context.fail( "Error: select QRA to get ID of Owner");
            return context.succeed(response);
        }



        if (info.length === 0){
            console.log("Caller user is not the QSO Owner");
            response.error = 400;
            response.message = "Error: Caller user is not the QSO Owner";
            conn.destroy();
            //return context.fail( "Error: Caller user is not the QSO Owner");
            return context.succeed(response);
        }

        //***********************************************************
        idqra_owner = JSON.parse(JSON.stringify(info))[0].idqras;
        qra_owner = JSON.parse(JSON.stringify(info))[0].qra;
        post  = {"idqsos_media": idmedia       
        };
        conn.query('UPDATE qsos_media SET deleted=1 WHERE idqsos_media=?', [idmedia], function(error, info) {
            if (error) {
                console.log("Error when Insert QSO MEDIA");
                console.log(error.message);
                conn.destroy();
                response.error = 400;
                response.message = "Error when Insert QSO MEDIA";
                //return context.fail( "Error when Insert QSO MEDIA");
                return context.succeed(response);
            } //End If
            console.log(info)
            if (info.insertId){
                //PUSH Notification
                payload = {
                    "commentID": info.insertID,
                    "qso": qso,
                    "owner": idqra_owner,
                    "owner_qra": qra_owner
                };
                var params = {
                    FunctionName: 'SNS-Media-Add', // the lambda function we are going to invoke
                    InvocationType: 'RequestResponse',
                    LogType: 'Tail',
                    Payload: JSON.stringify(payload)
                };
               
                //console.log(comments);

            }
        }); //End Insert
    });
};