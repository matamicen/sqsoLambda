var fs = require('fs');
var mysql = require('mysql');

/*{     "mode": "modetest1",
 "band": "bandtest1",
 "qra_owner": "lu2ach",
 "longitude": "1",
 "latitude": "1",
 "datetime": "2016-04-28 14:12:00",
 "state": "statetest1",
 "type": "QSO",
 "qras": ["LU1BJW",
 "LU3QQQ",
 "LU8AJ",
 "LU9DO"],
 }
 */


exports.handler = (event, context, callback) =>
{
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Received context:', JSON.stringify(context, null, 2));

    var post;    
    var json;
    var idqra;
    var newid;
    var datetime;
    var sub;
    var msg;
    var detail;
    var idcomment;
    var idmedia;
    var idqso;

    if (process.env.TEST) {
        var test = {           
            "datetime": "2016-04-28 14:12:00",
            "idqso": '1265',
            "idcomment": '296',
            "idmedia": '1880',
            "detail" : "content is offensive",       

        };
        datetime = test.datetime;    
        idqso = test.idqso;
        idcomment = test.idcomment;
        idmedia = test.idmedia;
        detail = test.detail;

        sub = '7bec5f23-6661-4ba2-baae-d1d4f0440038';
    }
    else {
        datetime = event.body.datetime;
        idqso = event.body.idqso;
        idcomment = event.body.idcomment;
        idmedia = event.body.idmedia;
        detail = event.body.detail;
        sub = event.context.sub;
    }
    console.log(sub);

    //***********************************************************
    var conn = mysql.createConnection({
        host: 'sqso.clqrfqgg8s70.us-east-1.rds.amazonaws.com',  // give your RDS endpoint  here
        user: 'sqso',  // Enter your  MySQL username
        password: 'parquepatricios',  // Enter your  MySQL password
        database: 'sqso'    // Enter your  MySQL database name.
    });


    // GET QRA ID of OWNER
    console.log("select QRA to get ID of Owner");

    conn.query("SELECT * FROM qras where idcognito=? LIMIT 1", sub, function (error, info) {
        if (error) {
            console.log("Error when select QRA to get ID of Owner");
            console.log(error);
            conn.destroy();

            msg = {
                "error": "1",
                "message": "Error when select QRA to get ID of Owner"
            };
            error = new Error("Error when select QRA to get ID of Owner");
            callback(error);
            return context.fail(msg);
        }
        else if (info.length === 0) {
            console.log("Error when select QRA to get ID of Owner");
            console.log(error);
            conn.destroy();

            msg = {
                "error": "1",
                "message": "Error when select QRA to get ID of Owner"
            };
            error = new Error("Error when select QRA to get ID of Owner");
            callback(error);
            return context.fail(msg);
        }
     
        idqra = JSON.parse(JSON.stringify(info))[0].idqras;

        
        
        post = {
            "idqra": idqra,
            "location": location,
            "idqso": idqso,
            "idcomment": idcomment,
            "idmedia": idmedia,
            "detail": detail,
            "datetime": datetime,            
        };
        console.log(post);

        //INSERT INTO CONTENT_REPORTED TABLE
            conn.query ( 'INSERT INTO content_reported SET ?', post,   function(error,info) {
       // conn.query('INSERT INTO content_reported  SET idqra_owner=?, location = GeomFromText(?), mode = ?, band = ?, datetime = ?, type = ?', [ idqras, location, mode, band, datetime, type], function (error, info) {
            console.log("insert QSO");
            if (error) {
                console.log("Error when insert QSO");
                console.log(error.message);
                conn.destroy();
                callback(error.message);
                return context.fail(error);
            }
            if (info.insertId) {
                console.log("QSO inserted", info.insertId);
                qso = JSON.stringify(info);
                json = JSON.parse(qso);
                newid = json.insertId;
                msg = {
                    "error": "0",
                    "message": newid
                };
                console.log("idqras" + idqras);
               


                //***********************************************************
                
                context.succeed(msg);
            } //ENDIF CONTENT_REPORTED Inserted
        }); //Insert CONTENT_REPORTED
    }); //END SELECT QRA
};